import { html, render } from "../lib/lithtml.js";

const template = () => html``;

export function detailsView() {
    render(template());
}