import { html, render } from "../lib/lithtml.js";

const template = () => html``;

export function createView() {
    render(template());
}